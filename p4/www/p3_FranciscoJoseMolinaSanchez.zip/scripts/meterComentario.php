<?php
    include("bd.php");

    // si hemos dado a enviar (submit)
    if (isset($_POST['submit'])){
        conectar();
        $url_anterior = $_SERVER['HTTP_REFERER'];
        $idEv = substr($url_anterior, strrpos($url_anterior, '/') + 1);
        $nombre = $mysqli->real_escape_string($_REQUEST['nombre']);
        $email = $mysqli->real_escape_string($_REQUEST['email']);
        $com = $mysqli->real_escape_string($_REQUEST['texto_comentario']);
        introducirComentario($idEv, $nombre, $email, $com);
        cerrar();
        header("Location: /evento/$idEv");
        exit();
    }
        
?>