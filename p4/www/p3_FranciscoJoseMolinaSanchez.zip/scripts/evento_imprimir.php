<?php
    $resto = substr($uri,17);
    $idEv = intval($resto);
    
    conectar();
    $evento = getEvento($idEv);
    $imagenes = getTodasImagenes($idEv);
    $comentarios = getComentarios($idEv);
    cerrar();
    echo $twig->render('evento_imprimir.html', ['evento' => $evento , 'imagenes' => $imagenes, 'comentarios' => $comentarios]);
?>