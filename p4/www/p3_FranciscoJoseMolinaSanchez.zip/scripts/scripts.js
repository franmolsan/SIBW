var PROHIBIDAS = [];
var ASTERISCOS = [];
function mostrarComentarios() 
{
  var x = document.getElementById("desplegable");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}

function getFecha()
{
    var hoy = new Date();
    var dd = hoy.getDate();
    var mm = hoy.getMonth()+1; // Enero es 0
    var yyyy = hoy.getFullYear();
    if(dd<10){dd='0'+dd} if(mm<10){mm='0'+mm}
    hoy = dd+"/"+mm+"/"+yyyy;

    return hoy;
}

function getHora()
{
 var hoy = new Date();
 var horas = hoy.getHours();
 var minutos = hoy.getMinutes();
 if(horas<10){horas='0'+horas} if(minutos<10){minutos='0'+minutos}

 return (horas+":"+minutos);
}

function validateForm() {

  // obtener el valor de los campos del comentario
  var nombre = document.forms["form_comentario"]["nombre"].value;
  var email = document.forms["form_comentario"]["email"].value;
  var com = document.getElementById("com").value;
  if (nombre == ""){
    alert ("El nombre no puede estar vacío");
    return false;
  } 

  else if (email == ""){
    alert ("El email no puede estar vacío");
    return false;
  }

  else if (!validaEmail(email)) {
    alert("Dirección de email no válida");
    return false;
  }

  else if ( /^\s*$/.test(com)) {
    alert("El comentario no puede estar vacío")
    return false;
  }

  return true;
}

function validaEmail (em)
{
  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(em)) {
    return true;
  }
  else {
    return false;
  }
}

function compruebaProhibidas() {
  
  var com = document.getElementById("com");

  var i;
  for (i=0; i<PROHIBIDAS.length; i++){
    // usamos la expresión regular porque con la opción "gi" 
    // nos permite ignorar las mayúsculas o minúsculas.
    var reg = new RegExp (PROHIBIDAS[i], 'gi');
    com.value = com.value.replace(reg, ASTERISCOS[i]);  
  }

}

// obtener las palabras prohibidas
// usando AJAX
function getProhibidas(){
  
  var xmlhttp = new XMLHttpRequest();

  xmlhttp.onreadystatechange = function() {

    // cuando hayamos obtenido respuesta
    if (this.readyState == 4 && this.status == 200) {

      // obtenemos la respuesta como un string, y luego lo 
      // separamos por espacios
      PROHIBIDAS = JSON.parse(this.responseText);

      for(var i =0; i < PROHIBIDAS.length; i++){
        var aste = "";
        for (var j=0; j < PROHIBIDAS[i].length; j++){
          aste = aste + "*";
        }
        ASTERISCOS.push(aste);
      }
    }
  };
 
  xmlhttp.open("GET","/scripts/obtenerProhibidas.php", true);
  xmlhttp.send();

}